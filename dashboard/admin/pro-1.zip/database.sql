-- ------------------------------------------------------------
-- DATABASE SUPER ADMIN MODULE
-- ------------------------------------------------------------
SET
    SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

START TRANSACTION;

SET
    time_zone = "+00:00";

-- ------------------------------------------------------------
-- TABLE: roles
-- ------------------------------------------------------------
CREATE TABLE
    `roles` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `nama_role` VARCHAR(100) NOT NULL,
        `deskripsi` TEXT DEFAULT NULL,
        `aktif` TINYINT (1) DEFAULT 1,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Insert default roles (Super Admin will add more later)
INSERT INTO
    `roles` (`id`, `nama_role`, `deskripsi`)
VALUES
    (1, 'super_admin', 'Full access to all modules'),
    (2, 'hrd_manager', 'Manage HR operations'),
    (3, 'admin_hrd', 'Admin HR department'),
    (4, 'staff_hrd', 'HR staff'),
    (5, 'supervisor', 'Supervisor role'),
    (6, 'customer_service', 'Handle tickets & chats'),
    (
        7,
        'karyawan_cleaning',
        'Employee: Cleaning Service'
    ),
    (
        8,
        'karyawan_security',
        'Employee: Security / Satpam'
    );

-- ------------------------------------------------------------
-- TABLE: users
-- ------------------------------------------------------------
CREATE TABLE
    `users` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `role_id` INT (11) NOT NULL,
        `nama_lengkap` VARCHAR(255) NOT NULL,
        `email` VARCHAR(255) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `no_hp` VARCHAR(50) DEFAULT NULL,
        `foto` VARCHAR(255) DEFAULT 'default.png',
        `alamat` TEXT DEFAULT NULL,
        `status` TINYINT (1) DEFAULT 1,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `fk_role_user` (`role_id`),
        CONSTRAINT `fk_role_user` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: struktur_organisasi
-- ------------------------------------------------------------
CREATE TABLE
    `struktur_organisasi` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `nama` VARCHAR(255) NOT NULL,
        `jabatan` VARCHAR(255) NOT NULL,
        `foto` VARCHAR(255) DEFAULT NULL,
        `facebook` VARCHAR(255) DEFAULT NULL,
        `instagram` VARCHAR(255) DEFAULT NULL,
        `linkedin` VARCHAR(255) DEFAULT NULL,
        `urutan` INT (11) DEFAULT 0,
        PRIMARY KEY (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: jasa
-- ------------------------------------------------------------
CREATE TABLE
    `jasa` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `nama_jasa` VARCHAR(255) NOT NULL,
        `tipe_jasa` ENUM ('kontrak', 'on_going') NOT NULL,
        `deskripsi` TEXT DEFAULT NULL,
        `harga_dasar` DOUBLE DEFAULT 0,
        `icon_url` VARCHAR(255) DEFAULT NULL,
        `aktif` TINYINT (1) DEFAULT 1,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: seo_analytics
-- ------------------------------------------------------------
CREATE TABLE
    `seo_analytics` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `page` VARCHAR(255) NOT NULL,
        `views` INT (11) DEFAULT 0,
        `clicks` INT (11) DEFAULT 0,
        `tanggal` DATE NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: financial
-- ------------------------------------------------------------
CREATE TABLE
    `financial` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `jenis` ENUM ('pemasukan', 'pengeluaran') NOT NULL,
        `jumlah` DOUBLE NOT NULL,
        `keterangan` TEXT DEFAULT NULL,
        `tanggal` DATE NOT NULL,
        `created_by` INT (11) NOT NULL,
        PRIMARY KEY (`id`),
        KEY `fk_financial_user` (`created_by`),
        CONSTRAINT `fk_financial_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: activity_logs
-- ------------------------------------------------------------
CREATE TABLE
    `activity_logs` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `user_id` INT (11) NOT NULL,
        `role_id` INT (11) NOT NULL,
        `aktivitas` TEXT NOT NULL,
        `ip_address` VARCHAR(255) DEFAULT NULL,
        `user_agent` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `fk_log_user` (`user_id`),
        KEY `fk_log_role` (`role_id`),
        CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
        CONSTRAINT `fk_log_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: users_online
-- ------------------------------------------------------------
CREATE TABLE
    `users_online` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `user_id` INT (11) NOT NULL,
        `last_login` DATETIME DEFAULT NULL,
        `last_activity` DATETIME DEFAULT NULL,
        `is_online` TINYINT (1) DEFAULT 0,
        PRIMARY KEY (`id`),
        KEY `fk_online_user` (`user_id`),
        CONSTRAINT `fk_online_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ------------------------------------------------------------
-- TABLE: schedules
-- ------------------------------------------------------------
CREATE TABLE
    `schedules` (
        `id` INT (11) NOT NULL AUTO_INCREMENT,
        `judul` VARCHAR(255) NOT NULL,
        `deskripsi` TEXT DEFAULT NULL,
        `tanggal_mulai` DATETIME NOT NULL,
        `tanggal_selesai` DATETIME DEFAULT NULL,
        `dibuat_oleh` INT (11) NOT NULL,
        `akses` ENUM (
            'all_role',
            'hrd_only',
            'supervisor_only',
            'karyawan_only'
        ) DEFAULT 'all_role',
        PRIMARY KEY (`id`),
        KEY `fk_schedule_user` (`dibuat_oleh`),
        CONSTRAINT `fk_schedule_user` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

COMMIT;